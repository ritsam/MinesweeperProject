Name: Ritika Samanta
Section: 18617
UFL email: ritika.samanta@ufl.edu
System: Windows 64
Compiler: MinGW 64
SFML version: 2.5.1 (2017) 64 bit
IDE: Visual Studio 2022
Other notes: None